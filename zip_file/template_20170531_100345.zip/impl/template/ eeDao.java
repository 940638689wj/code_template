import cn.yr.chile.common.persistence.CrudDao;
import cn.yr.chile.common.persistence.annotation.MyBatisDao;

@MyBatisDao
public interface  eeDao extends CrudDao< ee> {

}
