
public class  eeDTO extends  ee{

}
