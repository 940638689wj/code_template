import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service(" eeService")
public class  eeServiceImpl implements  eeService {
    @Autowired
    private  eeDao dao;

    /**
     * 新增/修改
     *
     * @param  ee id不存在则新增，存在则修改
     */
    @Override
    public void save( ee  ee){
        if ( ee.getAa() == null) {
            //todo
            this.insert( ee);
        } else {
            //todo
            this.update( ee);
        }
    }

    @Override
    public void insert( ee  ee){
        dao.insert( ee);
    }

    @Override
    public void delete(Integer id){
        dao.delete(id);
    }

    @Override
    public void update( ee  ee){
        dao.update( ee);
    }

    @Override
    public  ee get(Integer id){
        return dao.get(id);
    }

}
