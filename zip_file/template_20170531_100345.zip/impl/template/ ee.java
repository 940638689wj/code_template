import cn.yr.chile.common.persistence.BaseEntity;

public class  ee extends BaseEntity< ee>{

    private String aa; //bb
    private String cc; //dd

    /**
      * 获取 bb
      */
    public String getAa(){
        return this.aa;
    }
    
    /**
      * 设置 bb
      */
    public void setAa(String aa){
        this.aa = aa;
    }
    
    /**
      * 获取 dd
      */
    public String getCc(){
        return this.cc;
    }
    
    /**
      * 设置 dd
      */
    public void setCc(String cc){
        this.cc = cc;
    }
    
}
