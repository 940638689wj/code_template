
public interface  eeService {

    /**
     * 新增/修改
     *
     * @param  ee id不存在则新增，存在则修改
     */
    void save( ee  ee);

    void insert( ee  ee);

    void delete(Integer id);

    void update( ee  ee);

     ee get(Integer id);

}
